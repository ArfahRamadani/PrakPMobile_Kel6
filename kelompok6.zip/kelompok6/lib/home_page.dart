import 'package:flutter/material.dart';
import 'package:kelompok6/api.dart';
import 'package:kelompok6/detail_page.dart';
import 'package:kelompok6/form_page.dart';
import 'package:kelompok6/user_model.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<UserModel> _users = [];

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  _loadUsers() async {
    final users = await Api().getUsers();
    setState(() {
      _users = users;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Pengguna'),
        centerTitle: true, // center the title
      ),
      body: _users.isEmpty
         ? Center(
              child: CircularProgressIndicator(), 
            )
          : ListView.builder(
              itemCount: _users.length,
              itemBuilder: (context, index) {
                return Card( 
                  child: ListTile(
                    title: Text(
                      _users[index].firstName + '' + _users[index].lastName,
                      style: TextStyle(fontSize: 18), 
                    ),
                    subtitle: Text(
                      _users[index].email,
                      style: TextStyle(fontSize: 16), 
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailPage(_users[index].id),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended( 
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FormPage(),
            ),
          );
        },
        label: Text('Tambah Pengguna'),
        icon: Icon(Icons.add),
      ),
    );
  }
}