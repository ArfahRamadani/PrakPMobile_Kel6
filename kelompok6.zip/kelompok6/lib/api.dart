import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:kelompok6/user_model.dart';

class Api {
  static const String _baseUrl = 'https://reqres.in/api';

  Future<List<UserModel>> getUsers() async {
    final response = await http.get(Uri.parse('$_baseUrl/users'));

    if (response.statusCode == 200) {
      List<UserModel> users = (jsonDecode(response.body)['data'] as List)
         .map((data) => UserModel.fromJson(data))
         .toList();
      return users;
    } else {
      throw Exception('Failed to load users');
    }
  }

  Future<UserModel> getUser(int id) async {
    final response = await http.get(Uri.parse('$_baseUrl/users/$id'));

    if (response.statusCode == 200) {
      return UserModel.fromJson(jsonDecode(response.body)['data']);
    } else {
      throw Exception('Failed to load user');
    }
  }

  Future<void> createUser(UserModel user) async {
    final response = await http.post(Uri.parse('$_baseUrl/users'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(user.toJson()));

    if (response.statusCode!= 201) {
      throw Exception('Failed to create user');
    }
  }
}