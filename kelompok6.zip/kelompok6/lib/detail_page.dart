import 'package:flutter/material.dart';
import 'package:kelompok6/api.dart';
import 'package:kelompok6/user_model.dart';


class DetailPage extends StatefulWidget {
  final int userId;

  DetailPage(this.userId);

  @override
  _DetailPageState createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  late UserModel _user;

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  _loadUser() async {
    final user = await Api().getUser(widget.userId);
    setState(() {
      _user = user;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Pengguna'),
        backgroundColor: Colors.blue, // change app bar background color
        centerTitle: true, // center the title
      ),
      body: _user != null
          ? Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, // align text to the left
                children: [
                  Text(
                    'ID: ${_user.id}',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold), // increase font size and make bold
                  ),
                  SizedBox(height: 8), // add spacing between text
                  Text(
                    'Nama Depan: ${_user.firstName}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Nama Belakang: ${_user.lastName}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Email: ${_user.email}',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            )
          : Center(
              child: CircularProgressIndicator(),
            ),
    );
  }
}