// lib/pages/form_page.dart

import 'package:flutter/material.dart';
import 'package:kelompok6/api.dart';
import 'package:kelompok6/user_model.dart';

class FormPage extends StatefulWidget {
  
  @override
  _FormPageState createState() => _FormPageState();
  
  void onUserAdded() {}
}

class _FormPageState extends State<FormPage> {
  final _formKey = GlobalKey<FormState>();
  late String _firstName, _lastName, _email;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah Pengguna Baru'),
        backgroundColor: Colors.blue, // change app bar background color
        centerTitle: true, // center the title
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0), // add padding to the form
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Nama Depan',
                  border: OutlineInputBorder(), // add border to the text field
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter first name';
                  }
                  return null;
                },
                onSaved: (value) => _firstName = value!,
              ),
              SizedBox(height: 16), // add spacing between text fields
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Nama Belakang',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter last name';
                  }
                  return null;
                },
                onSaved: (value) => _lastName = value!,
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value!.isEmpty || !value.contains('@')) {
                    return 'Please enter valid email';
                  }
                  return null;
                },
                onSaved: (value) => _email = value!,
              ),
              SizedBox(height: 24), // add more spacing before the button
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, backgroundColor: Colors.blue, // change button text color
                ),
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    var id = null;
                    final user = UserModel(
                      firstName: _firstName,
                      lastName: _lastName,
                      email: _email,
                      id: id,
                    );
                    await Api().createUser(user);
                    widget.onUserAdded();
                    Navigator.pop(context);
                  }
                },
                child: Text('Tambah Pengguna'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}